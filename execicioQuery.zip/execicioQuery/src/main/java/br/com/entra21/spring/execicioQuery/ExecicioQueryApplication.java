package br.com.entra21.spring.execicioQuery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExecicioQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExecicioQueryApplication.class, args);
	}

}
