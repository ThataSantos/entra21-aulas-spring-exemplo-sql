package br.com.entra21.spring.execicioQuery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExecicioQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
